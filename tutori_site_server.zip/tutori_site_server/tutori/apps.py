from django.apps import AppConfig


class TutoriConfig(AppConfig):
    name = 'tutori'
